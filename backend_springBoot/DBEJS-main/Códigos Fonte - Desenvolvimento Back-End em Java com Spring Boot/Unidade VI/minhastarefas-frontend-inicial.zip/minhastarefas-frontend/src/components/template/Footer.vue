<template>
  <v-footer absolute app class="font-weight-medium">
    <v-col class="text-center" cols="12">
      {{ new Date().getFullYear() }} — <strong>Minhas Tarefas</strong>
    </v-col>
  </v-footer>
</template>

<script>
export default {};
</script>

<style>
</style>