package br.com.tarefas.model;

public enum ERole {
	
	ROLE_USER, ROLE_ADMIN
	
}
