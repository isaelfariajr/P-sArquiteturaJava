package br.com.uniciv.contatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContatosManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
