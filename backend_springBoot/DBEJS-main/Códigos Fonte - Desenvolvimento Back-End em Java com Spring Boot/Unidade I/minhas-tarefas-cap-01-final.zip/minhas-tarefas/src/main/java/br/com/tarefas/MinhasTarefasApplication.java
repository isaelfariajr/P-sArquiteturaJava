package br.com.tarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhasTarefasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhasTarefasApplication.class, args);
	}

}
