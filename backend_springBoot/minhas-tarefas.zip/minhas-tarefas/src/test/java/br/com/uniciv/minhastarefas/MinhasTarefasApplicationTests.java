package br.com.uniciv.minhastarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhasTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
