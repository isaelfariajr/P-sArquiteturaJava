package br.com.uniciv.contados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContadosManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
