package br.com.uniciv.contados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContadosManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContadosManagerApplication.class, args);
	}

}
